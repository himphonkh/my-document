# learnEnglish

<br>1. import mysql "server-test"

<br>2. import Project to netbeans

<br>3. add library >> add JAV file >> mysql-connector.java 
