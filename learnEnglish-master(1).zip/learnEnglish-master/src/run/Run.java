/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package run;
import view.*;

/**
 *
 * @author reach
 */
public class Run {
    public static void main(String[] args) {
//        LoginPage login = new LoginPage();
//        login.setVisible(true);
        Dashboard ds = new Dashboard();
        ds.setVisible(true);
    }
}
